from ems import views
from django.urls import path
urlpatterns=[

    path('ems/',views.user,name='ggc'),

    path('add-std/',views.add,name='add'),
    path('list-std/',views.view,name='list'),

    path('sadd/',views.attendance,name='list3'),
    path('sv/',views.aview,name='list2'),
    path('ap/',views.attp,name='appp'),


]