from django.db import models

class Student(models.Model):
    name=models.CharField(max_length=30)
    address=models.CharField(max_length=40)
    usn=models.IntegerField(primary_key=True)
    clas=models.CharField(max_length=30)
    bloodgroup=models.CharField(max_length=30)


class Attendance(models.Model):
    name=models.CharField(max_length=30)
    usn=models.IntegerField()
    clas=models.CharField(max_length=30)
    date=models.CharField(max_length=30)
    per=models.IntegerField(max_length=30,default=50)
