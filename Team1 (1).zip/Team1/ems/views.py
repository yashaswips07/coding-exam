from django.shortcuts import render,redirect
from .models import *
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.contrib import messages




# Create your views here.

def user(request):
    return render(request,'index.html',context={})



def add(request):
    if request.method == 'POST':
        a=request.POST.get('name')
        b=request.POST.get('address')
        c=request.POST.get('usn')
        d=request.POST.get('clas')
        e=request.POST.get('bloodgroup')
        f= Student(name=a,address=b,usn=c,clas=d,bloodgroup=e)
        f.save()
        

    else:
        return render(request,'page4.html',context={})
    return HttpResponse('Data is inserted sucessfully')
       
    
def view(request):
    sms=Student.objects.all()
    return render(request,'ll.html',context={'sms':sms})





def attendance(request):
    if request.method == 'POST':
        a=request.POST.get('name')
        b=request.POST.get('usn')
        c=request.POST.get('clas')
        e=request.POST.get('date')
        f=request.POST.get('per')
        d= Attendance(name=a,usn=b,clas=c,date=e,per=f)
        d.save()
    else:
        return render(request,'dadd.html',context={})
    return HttpResponse('Data is inserted sucessfully')



def aview(request):
    ps=Attendance.objects.all()
    return render(request,'sv.html',context={'ps':ps})

def attp(request):
    ap=Attendance.objects.all()
    return render(request,'ap.html',context={'ap':ap})